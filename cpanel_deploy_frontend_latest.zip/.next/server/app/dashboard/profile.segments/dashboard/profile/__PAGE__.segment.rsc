1:"$Sreact.fragment"
2:I[99278,["/_next/static/chunks/30jvh5usxocgq.js","/_next/static/chunks/0p-cb2s10c1us.js","/_next/static/chunks/3w3-wny11-p46.js","/_next/static/chunks/031d4hdncmqdj.js","/_next/static/chunks/0441zhia4-33z.js","/_next/static/chunks/08bsj3vof7s29.js","/_next/static/chunks/3slrpl0b9q_p2.js","/_next/static/chunks/0nvj57r0dukr0.js","/_next/static/chunks/33ga21hg1vqqw.js"],"ProfileLayout"]
3:I[97367,["/_next/static/chunks/30jvh5usxocgq.js","/_next/static/chunks/0p-cb2s10c1us.js","/_next/static/chunks/3w3-wny11-p46.js","/_next/static/chunks/031d4hdncmqdj.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"rsc":["$","$1","c",{"children":[["$","$L2",null,{}],[["$","script","script-0",{"src":"/_next/static/chunks/3slrpl0b9q_p2.js","async":true}],["$","script","script-1",{"src":"/_next/static/chunks/0nvj57r0dukr0.js","async":true}],["$","script","script-2",{"src":"/_next/static/chunks/33ga21hg1vqqw.js","async":true}]],["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"-mJPvSfZd1N9oHgi1QPlr"}
5:null
