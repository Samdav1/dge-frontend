1:"$Sreact.fragment"
2:I[39756,["/_next/static/chunks/30jvh5usxocgq.js","/_next/static/chunks/0p-cb2s10c1us.js","/_next/static/chunks/3w3-wny11-p46.js","/_next/static/chunks/031d4hdncmqdj.js"],"default"]
3:I[37457,["/_next/static/chunks/30jvh5usxocgq.js","/_next/static/chunks/0p-cb2s10c1us.js","/_next/static/chunks/3w3-wny11-p46.js","/_next/static/chunks/031d4hdncmqdj.js"],"default"]
4:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W4","buildId":"-mJPvSfZd1N9oHgi1QPlr"}
