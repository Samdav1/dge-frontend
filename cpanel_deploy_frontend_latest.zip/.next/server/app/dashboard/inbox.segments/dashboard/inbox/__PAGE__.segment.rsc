1:"$Sreact.fragment"
2:"$Sreact.suspense"
3:I[22097,["/_next/static/chunks/30jvh5usxocgq.js","/_next/static/chunks/0p-cb2s10c1us.js","/_next/static/chunks/3w3-wny11-p46.js","/_next/static/chunks/031d4hdncmqdj.js","/_next/static/chunks/0441zhia4-33z.js","/_next/static/chunks/08bsj3vof7s29.js","/_next/static/chunks/05auo8cziz0a1.js"],"InboxLayout"]
4:I[97367,["/_next/static/chunks/30jvh5usxocgq.js","/_next/static/chunks/0p-cb2s10c1us.js","/_next/static/chunks/3w3-wny11-p46.js","/_next/static/chunks/031d4hdncmqdj.js"],"OutletBoundary"]
0:{"rsc":["$","$1","c",{"children":[["$","$2",null,{"fallback":["$","div",null,{"children":"Loading inbox..."}],"children":["$","$L3",null,{}]}],[["$","script","script-0",{"src":"/_next/static/chunks/05auo8cziz0a1.js","async":true}]],["$","$L4",null,{"children":["$","$2",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"-mJPvSfZd1N9oHgi1QPlr"}
5:null
