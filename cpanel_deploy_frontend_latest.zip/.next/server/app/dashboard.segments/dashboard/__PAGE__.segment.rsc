1:"$Sreact.fragment"
3:I[97367,["/_next/static/chunks/30jvh5usxocgq.js","/_next/static/chunks/0p-cb2s10c1us.js","/_next/static/chunks/3w3-wny11-p46.js","/_next/static/chunks/031d4hdncmqdj.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"rsc":["$","$1","c",{"children":["$L2",null,["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"-mJPvSfZd1N9oHgi1QPlr"}
5:null
2:E{"digest":"NEXT_REDIRECT;replace;/dashboard/marketplace;307;"}
