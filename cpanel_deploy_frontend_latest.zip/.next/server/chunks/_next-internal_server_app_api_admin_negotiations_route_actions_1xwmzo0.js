module.exports=[28232,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_negotiations_route_actions_1xwmzo0.js.map