module.exports=[74970,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_teams_route_actions_1l8sz2t.js.map