module.exports=[60712,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_platform-users_%5Bid%5D_route_actions_044i0rh.js.map