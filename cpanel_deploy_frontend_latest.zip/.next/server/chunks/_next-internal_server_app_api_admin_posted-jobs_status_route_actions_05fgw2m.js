module.exports=[82682,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_posted-jobs_status_route_actions_05fgw2m.js.map