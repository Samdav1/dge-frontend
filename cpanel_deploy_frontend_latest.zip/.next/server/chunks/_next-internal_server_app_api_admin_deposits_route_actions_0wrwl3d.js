module.exports=[31803,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_deposits_route_actions_0wrwl3d.js.map