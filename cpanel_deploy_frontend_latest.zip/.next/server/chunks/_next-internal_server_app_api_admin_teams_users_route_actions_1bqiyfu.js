module.exports=[51493,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_teams_users_route_actions_1bqiyfu.js.map