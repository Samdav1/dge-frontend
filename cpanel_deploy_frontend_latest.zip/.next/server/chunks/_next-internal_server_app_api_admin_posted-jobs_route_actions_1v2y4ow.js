module.exports=[37649,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_posted-jobs_route_actions_1v2y4ow.js.map