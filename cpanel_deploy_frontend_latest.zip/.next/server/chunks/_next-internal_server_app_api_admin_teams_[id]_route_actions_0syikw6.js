module.exports=[89633,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_teams_%5Bid%5D_route_actions_0syikw6.js.map