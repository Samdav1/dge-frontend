module.exports=[32264,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_platform-users_route_actions_15y6bjw.js.map