module.exports=[64105,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_services_status_route_actions_0nf65-b.js.map