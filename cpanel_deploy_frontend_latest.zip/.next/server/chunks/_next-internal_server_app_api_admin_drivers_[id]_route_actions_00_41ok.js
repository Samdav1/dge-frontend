module.exports=[7650,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_drivers_%5Bid%5D_route_actions_00_41ok.js.map