module.exports=[43402,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_fee-config_route_actions_0nomi0l.js.map