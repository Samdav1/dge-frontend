module.exports=[87375,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_revenue_route_actions_0m242qu.js.map