module.exports=[35984,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_negotiations_%5Bid%5D_route_actions_0xv2vca.js.map