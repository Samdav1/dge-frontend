module.exports=[8005,(e,o,d)=>{}];

//# sourceMappingURL=1oeh_server_app_api_admin_notifications_preferences_route_actions_1j0nzji.js.map