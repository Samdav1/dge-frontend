module.exports=[37054,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_drivers_route_actions_1j4g6xi.js.map